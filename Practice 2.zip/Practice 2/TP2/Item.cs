﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TP2
{
    public struct Item
    {
        public string Key;
        public string Value;
    }
}
